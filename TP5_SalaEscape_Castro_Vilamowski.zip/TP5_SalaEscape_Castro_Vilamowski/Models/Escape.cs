public static class Escape
{
    private static string[] incognitasSalas= new string [4];
    private static int estadoJuego=1;
    private static void InicializarJuego(){
        incognitasSalas[0]="YODA";
        incognitasSalas[1]="Hutt";
        incognitasSalas[2]="Sonido";
        incognitasSalas[3]="420";
    }
    public static int GetEstadoJuego(){
        return estadoJuego;
    }
    public static bool ResolverSala(int Sala, string Incognita){
        bool puede=false;
            InicializarJuego();
        if(Sala==estadoJuego){
            if(Incognita==incognitasSalas[estadoJuego-1]){
               puede=true; 
               estadoJuego++;
            }
        }
        return puede;
    }
}